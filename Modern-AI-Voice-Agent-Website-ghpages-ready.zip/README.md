
  # Modern AI Voice Agent Website

  This is a code bundle for Modern AI Voice Agent Website. The original project is available at https://www.figma.com/design/3lH032RMAeAcaVjkaOtBnm/Modern-AI-Voice-Agent-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  